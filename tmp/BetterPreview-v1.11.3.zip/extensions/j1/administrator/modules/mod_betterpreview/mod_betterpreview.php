<?php
/**
 * Main Module File
 * Does all the magic!
 *
 * @package			Better Preview
 * @version			1.11.3
 *
 * @author			Peter van Westen <peter@nonumber.nl>
 * @link			http://www.nonumber.nl
 * @copyright		Copyright © 2011 NoNumber! All Rights Reserved
 * @license			http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die();

/**
 * Module that gives a preview link
 */

// return if NoNumber! Framework plugin is not installed
jimport( 'joomla.filesystem.file' );
if ( !JFile::exists( JPATH_PLUGINS.'/system/nnframework/nnframework.php' ) ) {
	return;
}

// Include the Helper
require_once dirname( __FILE__ ).'/betterpreview/helper.php';
$helper = new modBetterPreview( $params );

$helper->render();