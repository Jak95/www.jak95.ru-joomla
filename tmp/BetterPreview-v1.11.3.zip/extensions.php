<?php
/**
 * Extension Install File
 * Does the stuff for the specific extensions
 *
 * @package			Better Preview
 * @version			1.11.3
 *
 * @author			Peter van Westen <peter@nonumber.nl>
 * @link			http://www.nonumber.nl
 * @copyright		Copyright © 2011 NoNumber! All Rights Reserved
 * @license			http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die();

$name = 'Better Preview';
$alias = 'betterpreview';
$ext = $name.' (system plugin)';

// SYSTEM PLUGIN
$states[] = installExtension( $alias, 'System - '.$name, 'plugin', array( 'folder' => 'system' ) );

// MODULE
$states[] = installExtension( $alias, $name, 'module', array( 'client_id' => '1' ), 1 );

// Stuff to do after installation / update
function afterInstall( &$db )
{
	// Place module in correct position
	$query = "UPDATE `#__modules`
		SET `position` = 'status',
			`published` = 1,
			`access` = 2,
			`client_id` = 1
		WHERE `module` = 'mod_betterpreview'";

	$db->setQuery( $query );
	$db->query();
}

// Stuff to do after installation / update
// For Joomla 1.5
function afterInstall_j1( &$db )
{
	$queries = array();

	// Place module in correct position
	$queries[] = "UPDATE `#__modules`
		SET `position` = 'status',
			`published` = 1,
			`access` = 2,
			`client_id` = 1
		WHERE `module` = 'mod_betterpreview'";

	// Rename old plugin name
	$queries[] = "UPDATE `#__plugins`
		SET `name` = 'System - Better Preview'
		WHERE `name` = 'System - BetterPreview' OR `name` = 'System - BetterPreview!'";

	foreach ( $queries as $query ) {
		$db->setQuery( $query );
		$db->query();
	}
}